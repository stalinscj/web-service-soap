<?php

	return array(
        "hostname"  => "192.168.0.110",
        "username"  => "uneg",
        "password"  => "uneg",
        "dbname"  	=> "uneg"
    );
?>