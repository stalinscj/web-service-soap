<?php
	return array(
        "hostname"  => "192.168.0.100",
        "username"  => "uneg_upata",
        "password"  => "uneg_upata",
        "dbname"  	=> "uneg_upata"
    );
?>